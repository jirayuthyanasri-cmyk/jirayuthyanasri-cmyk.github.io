Fresh Keeper - UX/UI Prototype (17 หน้า)
เปิด index.html เพื่อเริ่มที่หน้าเข้าสู่ระบบ แล้วกดปุ่ม/เมนูเพื่อเปลี่ยนหน้า
วิธีขึ้นเว็บ: ลากทั้งโฟลเดอร์ไปที่ https://app.netlify.com/drop
